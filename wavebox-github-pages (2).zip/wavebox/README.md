# Wavebox

Wavebox는 음악 감상 화면과 YouTube 영상 화면을 분리한 개인용 정적 웹 음악 서비스입니다. 프레임워크나 빌드 과정 없이 `index.html`에서 바로 실행되며 GitHub Pages에 배포할 수 있습니다.

## 실제 구현된 기능

- 저장소에 포함된 오리지널 WAV 4곡 실제 재생
- 재생/일시 정지, 이전/다음, 탐색, 볼륨, 음소거
- 셔플, 전체 반복, 한 곡 반복
- 검색, 즐겨찾기, 최근 재생
- 재생목록 생성, 곡 추가, 전체 재생, 삭제
- localStorage 상태 유지
- 별도 영상 화면과 YouTube URL/ID 임베드
- 영상 시작 시 음악 일시 정지
- 반응형 데스크톱/모바일 레이아웃
- 온라인/오프라인 상태 및 빈 상태
- 키보드: Space, M, 좌우 화살표

## 실행

가장 단순한 방법은 `index.html`을 여는 것입니다. 브라우저 정책 때문에 로컬 파일 재생이 제한되면 프로젝트 폴더에서 다음 명령을 사용하세요.

```bash
python3 -m http.server 8080
```

그 후 브라우저에서 `http://localhost:8080`을 엽니다.

## GitHub Pages 배포

1. 새 GitHub 저장소를 만듭니다.
2. 이 폴더의 파일 전체를 저장소 루트에 업로드합니다.
3. 저장소의 Settings → Pages로 이동합니다.
4. Deploy from a branch, `main`, `/ (root)`를 선택합니다.

모든 내부 경로는 상대 경로라 프로젝트 저장소 하위 URL에서도 동작합니다.

## 외부 의존성

- 음악 재생: 외부 의존성 없음. `assets/audio`의 생성 오디오를 사용합니다.
- 영상: YouTube 연결 및 해당 영상의 임베드 허용 상태가 필요합니다.
- 사용자 데이터: 서버로 전송하지 않고 해당 브라우저의 localStorage에만 저장됩니다.

## 알려진 제한

- 영상 검색 API는 포함하지 않았습니다. URL 또는 영상 ID 입력과 추천 목록 방식입니다.
- 재생목록 곡 추가는 개인용 단순 UI를 위해 번호 입력 창을 사용합니다.
- 브라우저 보안 정책상 새로고침 후 자동 재생하지 않습니다.
- YouTube 영상은 게시자 설정, 국가 제한 또는 네트워크 정책으로 재생되지 않을 수 있습니다.

## 구조

```text
wavebox/
├── index.html
├── styles.css
├── app.js
├── assets/audio/*.wav
├── docs/PROJECT_REPORT.md
├── README.md
└── LICENSE
```
